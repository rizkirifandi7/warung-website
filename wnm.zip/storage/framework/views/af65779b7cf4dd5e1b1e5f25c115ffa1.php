<?php if (isset($component)) { $__componentOriginal9d41032d5dde91ab243771384dacb5df = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d41032d5dde91ab243771384dacb5df = $attributes; } ?>
<?php $component = App\View\Components\FrontLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('front-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\FrontLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <!-- Hero -->
    <div class="pt-10">
        <div class="hero min-h-[40vh] max-w-7xl mx-auto rounded-md"
            style="background-image: url(<?php echo e(asset('storage/' . $content['hero']['image'])); ?>);">
            <div class="hero-overlay bg-opacity-60 rounded-md"></div>
            <div class="max-w-7xl mx-auto hero-content text-[#FF8F00]  text-center rounded-md">
                <div class="max-w-lg">
                    <h1 class="mb-5 text-5xl font-bold font-lilita"><?php echo e($content['hero']['title']); ?></h1>
                    <p class="mb-5 font-medium ">
                        <?php echo e($content['hero']['text']); ?>

                    </p>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-7xl mx-auto pt-6 pb-10">
        <!-- Categories -->
        <div
            class="flex flex-row sticky md:static top-0 left-0 right-0  py-6 gap-4 z-40 overflow-x-auto no-scrollbar">
            <span class="badge cursor-pointer p-4 badge-lg active bg-[#FF8F00]  text-white" data-category-id="all">All
                Category</span>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <span class="badge cursor-pointer p-4 badge-lg bg-orange-100"
                    data-category-id="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></span>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <!-- Menu List -->
        <section id="menu_list">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" id="menu-list">
                <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="card bg-white border border-[#FF8F00]  rounded-md">
                        <figure>
                            <?php if($menu->image): ?>
                                <img class="w-full object-cover h-[250px]" src="<?php echo e(asset('storage/' . $menu->image)); ?>" />
                            <?php else: ?>
                                <img class="w-full object-cover h-[250px]"
                                    src="<?php echo e(asset('storage/' . 'menu-images/default.png')); ?>" />
                            <?php endif; ?>
                        </figure>
                        <div class="flex flex-col gap-1.5 p-5 text-[#2E7D32] border-t border-[#FF8F00] ">
                                <h2 class="text-lg font-medium text-[#2E7D32]">
                                    <?php echo e($menu->name); ?>

                                </h2>
                                <div class="card-actions">
                                    <div class="px-2 py-0.5 border text-[#2E7D32] border-[#2E7D32] rounded-full text-sm">
                                        <?php echo e($menu->category->name); ?></div>
                                </div>
                                <p class="text-xl font-bold text-[#2E7D32]">Rp<?php echo e(number_format($menu->price, 0)); ?></p>
                            </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p>We're sorry... We can't find the menu you want...</p>
                <?php endif; ?>
            </div>
        </section>
    </div>

    <script>
        document.querySelectorAll('.badge').forEach(badge => {
            badge.addEventListener('click', function () {
                let categoryId = this.getAttribute('data-category-id');
                let csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');

                // Remove Selected Category Class
                document.querySelectorAll('.badge').forEach(badge => {
                    badge.classList.remove('bg-[#FF8F00] ', 'text-white');
                    badge.classList.add('bg-indigo-100');
                });

                // Set Selected Category Class
                this.classList.remove('bg-orange-100');
                this.classList.add('bg-[#FF8F00] ', 'text-white');

                fetch('/menu/filter', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                        'X-CSRF-TOKEN': csrfToken
                    },
                    body: JSON.stringify({
                        category_id: categoryId
                    })
                })
                    .then(response => response.json())
                    .then(data => {
                        let menuList = document.getElementById('menu-list');
                        menuList.innerHTML = '';

                        // Render card menu yang difilter
                        data.menus.forEach(menu => {
                            menuList.innerHTML += `
                        <div class="card bg-white border border-[#FF8F00]  rounded-md">
                            <figure>
                                ${menu.image ?
                                    `<img class="w-full object-cover h-[250px]" src="/storage/${menu.image}" />`
                                    :
                                    `<img class="w-full object-cover h-[250px]" src="/storage/menu-images/default.png" />`
                                }
                            </figure>
                            <div class="flex flex-col gap-1.5 p-5 text-greern-700 border-t border-[#FF8F00] ">
                                <h2 class="text-lg font-medium text-[#2E7D32]">
                                    ${menu.name}
                                </h2>
                                <div class="card-actions">
                                    <div class="px-2 py-0.5 border border-[#2E7D32] text-[#2E7D32] rounded-full text-sm">
                                        ${menu.category.name}</div>
                                </div>
                                <p class="text-xl font-extrabold text-[#2E7D32]">Rp${parseFloat(menu.price).toFixed(0)}</p>
                            </div>
                        </div>
                    `;
                        });
                    });
            });
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $attributes = $__attributesOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__attributesOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d41032d5dde91ab243771384dacb5df)): ?>
<?php $component = $__componentOriginal9d41032d5dde91ab243771384dacb5df; ?>
<?php unset($__componentOriginal9d41032d5dde91ab243771384dacb5df); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\wnm-website\resources\views/front/menu.blade.php ENDPATH**/ ?>