<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Dashboard')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="grid grid-cols-1 md:grid-cols-2 gap-4 items-start">
                <div class="bg-white p-8 rounded-md border border-[#FF8F00]">
                    <h3 class="text-black font-bold text-2xl">Manage Website</h3>
                    <div class="py-2">
                        <div class="divider divider-start">
                            <h4 class="font-medium text-lg text-black">Website Logo</h4>
                        </div>
                        <div class="card">
                            <div class="card-body flex gap-4 flex-row justify-between items-center p-4">
                                <div class="flex gap-4 items-center">
                                    <img src="<?php echo e(asset('storage/' . $logo['content']['company']['logo'])); ?>" alt="Logo" class="w-20 my-4">
                                    <p class="font-bold text-xl text-black"><?php echo e($logo['content']['company']['name']); ?></p>
                                </div>
                                <div class="card-actions justify-end">
                                    <a class="btn btn-ghost" href="<?php echo e(route('front-pages.edit', $logo)); ?>">
                                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-pencil">
                                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                            <path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4" />
                                            <path d="M13.5 6.5l4 4" />
                                        </svg>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="py-2">
                        <div class="divider divider-start">
                            <h4 class="font-medium text-lg text-black">Website Pages</h4>
                        </div>
                        <div class="grid grid-cols-1 gap-4">
                            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="card border-gray-600 border">
                                <div class="card-body flex flex-row justify-between items-center p-4">
                                    <div>
                                        <h2 class="card-title text-black"><?php echo e($page->name); ?></h2>
                                        <p class="text-sm opacity-70 ">Last updated on: <?php echo e($page->updated_at->diffForHumans()); ?></p>
                                    </div>
                                    <div class="card-actions justify-end">
                                        <a class="btn btn-ghost" href="<?php echo e(route('front-pages.edit', $page)); ?>">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-pencil">
                                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                                <path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4" />
                                                <path d="M13.5 6.5l4 4" />
                                            </svg>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
                <div class="bg-white p-8 rounded-md border border-[#FF8F00]">
                    <h3 class="font-bold text-2xl mb-4 text-black">Latest Messages</h3>
                    <div class="overflow-x-auto mb-4">
                        <table class="table table-fixed">
                            <thead>
                                <tr>
                                    <th class="w-[2rem] text-black">#</th>
                                    <th class="w-[6rem] text-black">Name</th>
                                    <th class="w-[12rem] text-black">Email</th>
                                    <th class="w-[12rem] text-black">Message</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1 + (10 * ((request('page') ?? 1) - 1)) ?>
                                <?php $__empty_1 = true; $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr class="text-black">
                                    <th><?php echo e($i++); ?></th>
                                    <td><?php echo e($message->name); ?></td>
                                    <td><?php echo e($message->email); ?></td>
                                    <td><?php echo e($message->message); ?></td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center">No message found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php if (isset($component)) { $__componentOriginalc362dce3f145e722207baadae879b314 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc362dce3f145e722207baadae879b314 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button-link','data' => ['class' => 'btn bg-[#2E7D32] text-white','href' => ''.e(route('messages.index')).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn bg-[#2E7D32] text-white','href' => ''.e(route('messages.index')).'']); ?>
                        <?php echo e(__('View More')); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $attributes = $__attributesOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__attributesOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $component = $__componentOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__componentOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <script>
        function showPreview() {
            const imageInput = document.querySelector('#image');
            const imagePreview = document.querySelector('.image-preview');

            const oFReader = new FileReader();
            oFReader.readAsDataURL(imageInput.files[0]);
            oFReader.onload = function(oFREvent) {
                imagePreview.src = oFREvent.target.result;
            }
        }
    </script>

    <!-- Sweet Alert - Start -->
    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            title: "<?php echo e(session()->get('success')); ?>",
            icon: "success"
        });
    </script>
    <?php endif; ?>
    <!-- Sweet Alert - End -->
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\wnm-website\resources\views/dashboard.blade.php ENDPATH**/ ?>