<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="max-w-7xl flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Front Pages')); ?>

            </h2>
            <?php if (isset($component)) { $__componentOriginalc362dce3f145e722207baadae879b314 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc362dce3f145e722207baadae879b314 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button-link','data' => ['href' => '/','class' => 'btn bg-[#2E7D32] text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => '/','class' => 'btn bg-[#2E7D32] text-white']); ?>View Website <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $attributes = $__attributesOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__attributesOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $component = $__componentOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__componentOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div class="divider divider-start text-2xl font-bold mb-8 text-[#FF8F00]">Pages</div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card bg-white rounded-md border border-[#FF8F00] shadow-md">
                <div class="card-body flex flex-row justify-between items-center">
                    <div>
                        <h2 class="card-title text-black"><?php echo e($page->name); ?></h2>
                        <p class="text-sm opacity-80">Last updated on: <?php echo e($page->updated_at->diffForHumans()); ?></p>
                    </div>
                    <div class="card-actions justify-end">
                        <a class="btn btn-ghost" href="<?php echo e(route('front-pages.edit', $page)); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-pencil">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M4 20h4l10.5 -10.5a2.828 2.828 0 1 0 -4 -4l-10.5 10.5v4" />
                                <path d="M13.5 6.5l4 4" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="divider divider-start text-2xl font-bold mb-8 text-[#FF8F00]">Components</div>
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-12">
            <!-- social media -->
            <div class="card bg-white rounded-md border border-[#FF8F00] shadow-md">
                <div class="card-body flex flex-row justify-between items-center">
                    <div>
                        <h2 class="card-title text-black">Social Media</h2>
                    </div>
                    <div class="card-actions justify-end">
                        <a class="btn btn-ghost" href="<?php echo e(route('social-media.index')); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-arrow-up-right text-[#2E7D32]">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M17 7l-10 10" />
                                <path d="M8 7l9 0l0 9" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

            <!-- teams -->
            <div class="card bg-white rounded-md border border-[#FF8F00] shadow-md">
                <div class="card-body flex flex-row justify-between items-center">
                    <div>
                        <h2 class="card-title text-black">Teams Member</h2>
                    </div>
                    <div class="card-actions justify-end">
                        <a class="btn btn-ghost" href="<?php echo e(route('teams.index')); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-arrow-up-right text-[#2E7D32]">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M17 7l-10 10" />
                                <path d="M8 7l9 0l0 9" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>

            <!-- product -> menu -->
            <div class="card bg-white rounded-md border border-[#FF8F00] shadow-md">
                <div class="card-body flex flex-row justify-between items-center">
                    <div>
                        <h2 class="card-title text-black">Product (Menu)</h2>
                    </div>
                    <div class="card-actions justify-end">
                        <a class="btn btn-ghost" href="<?php echo e(route('menus.index')); ?>">
                            <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-arrow-up-right text-[#2E7D32]">
                                <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                                <path d="M17 7l-10 10" />
                                <path d="M8 7l9 0l0 9" />
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Sweet Alert - Start -->
    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            title: "<?php echo e(session()->get('success')); ?>",
            icon: "success"
        });
    </script>
    <?php endif; ?>
    <!-- Sweet Alert - End -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\wnm-website\resources\views/front-pages/index.blade.php ENDPATH**/ ?>