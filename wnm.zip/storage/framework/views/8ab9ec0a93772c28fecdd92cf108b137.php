<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="max-w-7xl flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Menus')); ?>

            </h2>
            <?php if (isset($component)) { $__componentOriginalc362dce3f145e722207baadae879b314 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc362dce3f145e722207baadae879b314 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.primary-button-link','data' => ['href' => ''.e(route('menus.create')).'','class' => 'btn bg-[#2E7D32] text-white']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('primary-button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => ''.e(route('menus.create')).'','class' => 'btn bg-[#2E7D32] text-white']); ?>New Menu <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $attributes = $__attributesOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__attributesOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc362dce3f145e722207baadae879b314)): ?>
<?php $component = $__componentOriginalc362dce3f145e722207baadae879b314; ?>
<?php unset($__componentOriginalc362dce3f145e722207baadae879b314); ?>
<?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="max-w-7xl mx-auto p-4 sm:p-6 lg:p-8">
        <div class="mb-4 mx-auto">
            <form action="" method="get">
                <div class="join w-full justify-center">
                    <div>
                        <div>
                            <input type="search" class="input input-bordered join-item w-[100px] md:w-96 bg-white text-black" placeholder="Search" name="search" value="<?php echo e(request('search')); ?>" />
                        </div>
                    </div>
                    <select class="select select-bordered join-item bg-white text-black" name="category">
                        <option value="" selected>All Category</option>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($category->slug); ?>" <?php echo e(request('category') == $category->slug ? 'selected' : ''); ?>><?php echo e($category->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <div class="indicator">
                        <button class="btn join-item border-none bg-[#FF8F00] text-white hover:bg-orange-400">Search</button>
                    </div>
                </div>
            </form>
            <?php if(request('search') || request('category')): ?>
            <a href="<?php echo e(route('menus.index')); ?>" class="text-blue-500 hover:underline text-sm mt-2 flex items-center justify-center">
                <span> clear filter </span>
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="icon icon-tabler icons-tabler-outline icon-tabler-rotate-2">
                    <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                    <path d="M15 4.55a8 8 0 0 0 -6 14.9m0 -4.45v5h-5" />
                    <path d="M18.37 7.16l0 .01" />
                    <path d="M13 19.94l0 .01" />
                    <path d="M16.84 18.37l0 .01" />
                    <path d="M19.37 15.1l0 .01" />
                    <path d="M19.94 11l0 .01" />
                </svg>
            </a>
            <?php endif; ?>
        </div>

        <div class="mt-6 bg-white p-2 rounded-md border border-[#FF8F00]">
            <div class="overflow-x-auto">
                <table class="table table-fixed">
                    <thead>
                        <tr class="text-black">
                            <th class="w-[2rem]">#</th>
                            <th class="w-[8rem] md:w-auto">Image</th>
                            <th class="w-[8rem] md:w-auto">Name</th>
                            <th class="w-[8rem] md:w-auto">Category</th>
                            <th class="w-[8rem] md:w-auto">Description</th>
                            <th class="w-[8rem] md:w-auto">Price</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1 + (10 * ((request('page') ?? 1) - 1)) ?>
                        <?php $__empty_1 = true; $__currentLoopData = $menus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr class="text-black">
                            <th><?php echo e($i++); ?></th>
                            <td>
                                <div class="avatar">
                                    <div class="w-16 rounded-xl">
                                        <?php if($menu->image): ?>
                                        <img src="<?php echo e(asset('storage/' . $menu->image)); ?>" />
                                        <?php else: ?>
                                        <img src="<?php echo e(asset('storage/' . 'menu-images/default.png')); ?>" />
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </td>
                            <td><?php echo e($menu->name); ?></td>
                            <td><?php echo e($menu->category->name); ?></td>
                            <td><?php echo e($menu->desc); ?></td>
                            <td><?php echo e(number_format($menu->price, 2)); ?></td>
                            <td>
                                <div class="space-x-2 flex flex-nowrap">
                                    <?php if (isset($component)) { $__componentOriginalf4c7e947771e44fa5ac8cc81575dd6c4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalf4c7e947771e44fa5ac8cc81575dd6c4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button-link','data' => ['class' => 'btn bg-yellow-500 text-white hover:text-black','href' => ''.e(route('menus.edit', $menu)).'']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn bg-yellow-500 text-white hover:text-black','href' => ''.e(route('menus.edit', $menu)).'']); ?>
                                        <?php echo e(__('Edit')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalf4c7e947771e44fa5ac8cc81575dd6c4)): ?>
<?php $attributes = $__attributesOriginalf4c7e947771e44fa5ac8cc81575dd6c4; ?>
<?php unset($__attributesOriginalf4c7e947771e44fa5ac8cc81575dd6c4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalf4c7e947771e44fa5ac8cc81575dd6c4)): ?>
<?php $component = $__componentOriginalf4c7e947771e44fa5ac8cc81575dd6c4; ?>
<?php unset($__componentOriginalf4c7e947771e44fa5ac8cc81575dd6c4); ?>
<?php endif; ?>
                                    <?php if (isset($component)) { $__componentOriginalee023de1cf73c3b5a141ff191bb76e0e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalee023de1cf73c3b5a141ff191bb76e0e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-ghost-button','data' => ['class' => 'btn bg-red-500 font-bold text-white','onclick' => 'showDeleteModal(\''.e($menu->slug).'\', \''.e($menu->name).'\')']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-ghost-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn bg-red-500 font-bold text-white','onclick' => 'showDeleteModal(\''.e($menu->slug).'\', \''.e($menu->name).'\')']); ?>
                                        <?php echo e(__('Delete')); ?>

                                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalee023de1cf73c3b5a141ff191bb76e0e)): ?>
<?php $attributes = $__attributesOriginalee023de1cf73c3b5a141ff191bb76e0e; ?>
<?php unset($__attributesOriginalee023de1cf73c3b5a141ff191bb76e0e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalee023de1cf73c3b5a141ff191bb76e0e)): ?>
<?php $component = $__componentOriginalee023de1cf73c3b5a141ff191bb76e0e; ?>
<?php unset($__componentOriginalee023de1cf73c3b5a141ff191bb76e0e); ?>
<?php endif; ?>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center">No menu found.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="mt-4">
            <?php echo e($menus->links()); ?>

        </div>
    </div>


    <!-- Delete Modal - Start -->
    <dialog id="deleteMenu" class="modal modal-bottom sm:modal-middle">
        <div class="modal-box">
            <h3 class="text-lg font-bold">Delete?</h3>
            <p class="py-4">Are you sure want to delete <strong id="modal-name" class="text-red-600">this</strong> menu?</p>
            <div class="modal-action">
                <form id="deleteForm" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('delete'); ?>
                    <div class="buttons mt-8 flex justify-end gap-4">
                        <?php if (isset($component)) { $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.secondary-button','data' => ['class' => 'btn','onclick' => 'document.getElementById(\'deleteMenu\').close();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('secondary-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'btn','onclick' => 'document.getElementById(\'deleteMenu\').close();']); ?><?php echo e(__('Cancel')); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $attributes = $__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__attributesOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af)): ?>
<?php $component = $__componentOriginal3b0e04e43cf890250cc4d85cff4d94af; ?>
<?php unset($__componentOriginal3b0e04e43cf890250cc4d85cff4d94af); ?>
<?php endif; ?>
                        <?php if (isset($component)) { $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.danger-button','data' => ['onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('danger-button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['onclick' => 'event.preventDefault(); this.closest(\'form\').submit();']); ?>
                            <?php echo e(__('Delete')); ?>

                         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $attributes = $__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__attributesOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11)): ?>
<?php $component = $__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11; ?>
<?php unset($__componentOriginal656e8c5ea4d9a4fa173298297bfe3f11); ?>
<?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
    </dialog>

    <script>
        function showDeleteModal(menuSlug, menuName) {
            const form = document.getElementById('deleteForm');
            form.action = `/admin/menus/${menuSlug}`;

            const modalName = document.getElementById('modal-name');
            modalName.textContent = menuName;

            document.getElementById('deleteMenu').showModal();
        }
    </script>
    <!-- Delete Modal - End -->

    <!-- Sweet Alert - Start -->
    <?php if(session()->has('success')): ?>
    <script>
        Swal.fire({
            title: "<?php echo e(session()->get('success')); ?>",
            icon: "success"
        });
    </script>
    <?php endif; ?>
    <!-- Sweet Alert - End -->

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\wnm-website\resources\views/menus/index.blade.php ENDPATH**/ ?>