<div class="bg-orange-500 border-t-2 border-orange-500">
    <footer class="footer max-w-7xl mx-auto p-10 md:justify-between">
        <aside>
            <a href="/">
                <img src="<?php echo e(asset('storage/' . $logo['content']['company']['logo'])); ?>" class="w-24">
            </a>
            <p class="text-2xl font-bold text-white">
                <?php echo e($logo['content']['company']['name']); ?>

            </p>
        </aside>
        <nav class="text-white">
            <h6 class="footer-title text-white opacity-100">Links</h6>
            <a class="link link-hover" href="<?php echo e(route('home')); ?>">Home</a>
            <a class="link link-hover" href="<?php echo e(route('menu')); ?>">Menu</a>
            <a class="link link-hover" href="<?php echo e(route('about')); ?>">About</a>
            <a class="link link-hover" href="<?php echo e(route('contact')); ?>">Contact</a>
        </nav>
        <nav class="text-white">
            <h6 class="footer-title text-white opacity-100">Social</h6>
            <div class="grid grid-flow-col gap-4">
                <?php $__currentLoopData = $socials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $social): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a href="<?php echo e($social->url); ?>" class="tooltip" data-tip="<?php echo e($social->username); ?>">
                    <img src="<?php echo e(asset('storage/' . $social->image)); ?>" alt="<?php echo e($social->name); ?>">
                </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </nav>
    </footer>
</div><?php /**PATH C:\xampp\htdocs\kopi-king\resources\views/layouts/front-footer.blade.php ENDPATH**/ ?>